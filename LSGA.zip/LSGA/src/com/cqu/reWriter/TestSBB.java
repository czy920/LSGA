package com.cqu.reWriter;

import com.cqu.core.EventListener;
import com.cqu.core.Result;
import com.cqu.core.Solver;

public class TestSBB {
    public static void main(String[] args) {
        Solver solver = new Solver();
        solver.solve("E:\\DCOP\\problems\\tiny_Test\\RandomDCOP_10_10_1.xml", "re_SBB", false, false, new EventListener() {
            @Override
            public void onStarted() {

            }
            @Override
            public void onFinished(Object result) {
                Result result1 = (Result) result;
            }
        });
    }
}
