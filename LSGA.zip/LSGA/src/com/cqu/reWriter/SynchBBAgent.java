package com.cqu.reWriter;

import com.cqu.core.Message;
import com.cqu.cyclequeue.AgentCycle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SynchBBAgent extends AgentCycle {
//    private int nextAgent;
//    private int prevAgent;
//    private int agentCount;
//    private ArrayList agentOrder = new ArrayList();

    public SynchBBAgent(int id, String name, int level, int[] domain) {
        super(id, name, level, domain);
    }
    public static final int TYPE_MSG_NEXT = 201;
    public static final int TYPE_MSG_PREV = 202;
    public static final int TYPE_MSG_ORDER = 203;
    public final static String TOTAL_COST = "TOTAL_COST";
    private int upperBound;
    private int accCost;
    private HashMap<Integer,Integer> currentParticalAssignment = new HashMap<>();

    @Override
    protected void initRun() {
        super.initRun();
        valueIndex = 0;
        upperBound = Integer.MAX_VALUE;
        accCost = 0;
        if (this.id == 1){
            HashMap<Integer,Integer> currentAssignment = new HashMap<>();
            currentAssignment.put(this.id,valueIndex);
            this.currentParticalAssignment.put(this.id,valueIndex);
            upperBound = Integer.MAX_VALUE;
            SBBContext sbbContext = new SBBContext(currentAssignment,upperBound,accCost);
            sendtoNextMessage(sbbContext);
        }
    }


    private void sendtoNextMessage(SBBContext context) {
        Message message = new Message(this.id,this.id+1,TYPE_MSG_NEXT,context);
        sendMessage(message);
    }

    @Override
    public Object printResults(List<Map<String, Object>> results) {
        return null;
    }

    @Override
    public String easyMessageContent(Message msg, AgentCycle sender, AgentCycle receiver) {
        return null;
    }

    @Override
    protected void disposeMessage(Message msg) {
        switch (msg.getType()){
            case TYPE_MSG_NEXT:
                disposeNextMessage(msg);
                break;
            case TYPE_MSG_PREV:
                disposePrevMessage(msg);
                break;
        }
    }

    private void disposePrevMessage(Message msg) {

        /*
        1. 更新upperBound
        2. 取值
        3. 判断是继续回溯还是取新值往下走
        * */
        this.upperBound = (int) msg.getValue();
        boolean isSend = false;
        for (int i = valueIndex+1; i < domain.length; i++) {
            int delta = calCost(valueIndex,currentParticalAssignment) - calCost(i,currentParticalAssignment);
            System.out.println("AgentId: " + this.id + "valueCount  " + valueIndex);
            if (delta >= 0){//valueIndex取新值，往下传sbbContext
                valueIndex = i;
                upperBound = upperBound - delta;
                currentParticalAssignment.put(this.id,valueIndex);
                accCost -= delta;
                SBBContext sbbContext = new SBBContext(currentParticalAssignment,upperBound,accCost);
                sendtoNextMessage(sbbContext);
                isSend = true;
                break;
            }
        }
        if (!isSend){
            if (this.id > 1){
                sendtoPrevMessage(upperBound);
            }else {
                System.out.println("Agent: " + this.id + "value:  " + valueIndex);
                System.out.println("TotalCost: " + upperBound);
                stopRunning();
            }
        }
    }

    private void disposeNextMessage(Message msg) {

        /*
        1. 存储累积接收到的CPA
        2. 累计计算accCost
        3. 判断是继续往下走还是剪枝回溯
        4. 更新upperBound值
        * */
        SBBContext sbbContext = (SBBContext) msg.getValue();
        HashMap<Integer,Integer> receivedAssignment =  sbbContext.getCurrentAsssignment();
        sumAssignment(this.currentParticalAssignment,receivedAssignment);
        boolean isSend = false;
        for (int i = 0; i < domain.length; i++) {
            int cost = calCost(i,currentParticalAssignment);
            accCost = sbbContext.getAccumulateCost();
            if (cost + accCost < upperBound){
                accCost = cost + accCost;
                valueIndex = i;
                currentParticalAssignment.put(this.id,valueIndex);
                if (this.id < 10){
                    sbbContext.setAccumulateCost(accCost);
                    sbbContext.setCurrentAsssignment(currentParticalAssignment);
                    isSend = true;
                    sendtoNextMessage(sbbContext);
                    break;
                }else {
                    upperBound = accCost;
                }
            }
        }
        if (!isSend){//剪枝
            sendtoPrevMessage(upperBound);
        }
    }
    @Override
    protected void runFinished() {
        super.runFinished();
        HashMap<String, Object> result = new HashMap<String,Object>();
        result.put(KEY_ID,this.id);
        result.put(KEY_NAME,this.name);
        result.put(KEY_VALUE,this.domain[valueIndex]);
        result.put(TOTAL_COST,this.upperBound);
        this.msgMailer.setResult(result);
    }

    private void sendtoPrevMessage(int upbound) {
        Message message = new Message(this.id,this.id-1,TYPE_MSG_PREV,upbound);
        sendMessage(message);
    }

    private int calCost(int value, HashMap<Integer, Integer> currentMap) {
        int cost = 0;
        for (int currentMapId : currentMap.keySet()) {
            for (int neighborId : neighbours) {
                if (currentMapId == neighborId){
                    cost += constraintCosts.get(currentMapId)[value][currentMap.get(currentMapId)];
                }
            }
        }
        return cost;
    }

    private void sumAssignment(HashMap<Integer, Integer> currentMap, HashMap<Integer, Integer> receivedMap) {
        for (int receContexId:receivedMap.keySet()) {
            currentMap.put(receContexId,receivedMap.get(receContexId));
        }
    }


    @Override
    protected void messageLost(Message msg) {

    }
}
