package com.cqu.reWriter;

import java.util.HashMap;

public class AdoptCostMessage {
    public HashMap<Integer,Integer> currentContext = new HashMap<>();
    public int lowBound;
    public int upperBound;

    public AdoptCostMessage(HashMap<Integer, Integer> currentContext, int lowBound, int upperBound) {
        this.currentContext = currentContext;
        this.lowBound = lowBound;
        this.upperBound = upperBound;
    }

    public HashMap<Integer, Integer> getCurrentContext() {
        return currentContext;
    }

    public void setCurrentContext(HashMap<Integer, Integer> currentContext) {
        this.currentContext = currentContext;
    }

    public int getLowBound() {
        return lowBound;
    }

    public void setLowBound(int lowBound) {
        this.lowBound = lowBound;
    }

    public int getUpperBound() {
        return upperBound;
    }

    public void setUpperBound(int upperBound) {
        this.upperBound = upperBound;
    }
}
