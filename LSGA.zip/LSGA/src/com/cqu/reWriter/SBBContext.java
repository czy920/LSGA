package com.cqu.reWriter;

import java.util.HashMap;

public class SBBContext {
    private HashMap<Integer,Integer> currentAsssignment = new HashMap<>();
    private int upBound;
    private int accumulateCost;

    public SBBContext(HashMap<Integer, Integer> currentAsssignment, int upBound, int accumulateCost) {
        this.currentAsssignment = currentAsssignment;
        this.upBound = upBound;
        this.accumulateCost = accumulateCost;
    }

    public HashMap<Integer, Integer> getCurrentAsssignment() {
        return currentAsssignment;
    }

    public void setCurrentAsssignment(HashMap<Integer, Integer> currentAsssignment) {
        this.currentAsssignment = currentAsssignment;
    }

    public int getUpBound() {
        return upBound;
    }

    public void setUpBound(int upBound) {
        this.upBound = upBound;
    }

    public int getAccumulateCost() {
        return accumulateCost;
    }

    public void setAccumulateCost(int accumulateCost) {
        this.accumulateCost = accumulateCost;
    }
}
