package com.cqu.reWriter;

import com.cqu.core.Agent;
import com.cqu.core.Message;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdoptAgent extends Agent {

    public static final int TYPE_VALUE_MESSAGE = 201;
    public static final int TYPE_COST_MESSAGE = 202;
    public static final int TYPE_THRESHOLD_MESSAGE = 203;
    public static final int TYPE_TERMINATE_MESSAGE = 204;

    private int threshold;
    private int lowBound;
    private int upperBound;
    private boolean isTerminate;
    private int[] lbList = new int[domain.length];
    private HashMap<Integer,Integer> currentContext = new HashMap<>();
    private HashMap<Integer,int[]> childrenLB = new HashMap<>();
    private HashMap<Integer,int[]> childrenUB = new HashMap<>();
    private HashMap<Integer,int[]> childrenTH = new HashMap<>();
    private HashMap<Integer,AdopContext> childrenContext = new HashMap<>();


    public AdoptAgent(int id, String name, int level, int[] domain) {
        super(id, name, level, domain);

    }

    @Override
    protected void initRun() {
        super.initRun();
        threshold = 0;
        isTerminate = false;
        for (int childIndex:children) {
            int [] lb = new int[domain.length];
            int [] ub = new int[domain.length];
            int [] th = new int[domain.length];
            for (int i = 0; i < domain.length; i++) {
                lb[i] = 0;
                ub[i] = Integer.MAX_VALUE;
                th[i] = 0;
            }
            childrenLB.put(childIndex,lb);
            childrenUB.put(childIndex,ub);
            childrenTH.put(childIndex,th);
        }
        valueIndex = getValueIndex();
        updateBound();
        backTrack();
    }

    private void updateBound() {
        int ub = Integer.MAX_VALUE;
        int tempUB = calLocalCost(valueIndex);
        int lb = calLocalCost(valueIndex);
        int tempLB = calLocalCost(valueIndex);
        for (int i = 0; i < domain.length; i++) {
            for (int neighborIndex:currentContext.keySet()) {
                tempLB += childrenLB.get(neighborIndex)[i];
                tempUB += childrenUB.get(neighborIndex)[i];
            }
            if (tempLB < lb){
                lb = tempLB;
            }
            if (tempUB < ub){
                ub = tempUB;
            }
        }
        upperBound = ub;
        lowBound = lb;
    }

    private void backTrack() {
        calLBview();
        if (threshold == upperBound){
            valueIndex = getValueIndex();
        }else if (lbList[valueIndex]>threshold){
            valueIndex = getMinLB();
        }
        sendValueMessage(valueIndex);
        maintanAllocationInvariant();
        if (threshold == upperBound){
            if (isTerminate || isRootAgent()){
                HashMap<Integer,Integer> contex = currentContext;
                contex.put(this.id,valueIndex);
                sendTerminateMessage(contex);
                stopRunning();
            }
        }
        AdoptCostMessage costMessage = new AdoptCostMessage(currentContext,lowBound,upperBound);
        sendCostMessage(costMessage);
    }

    private int getMinLB() {
        int tempLB = Integer.MAX_VALUE;
        int tempValue = -1;
        for (int i = 0; i < domain.length; i++) {
            if (tempLB > lbList[i]){
                tempLB = lbList[i];
                tempValue = i;
            }
        }
        return tempValue;
    }

    private void calLBview() {
        for (int i = 0; i < domain.length; i++) {
            int lb = calLocalCost(i);
            for (int childIndex : children) {
                lb += childrenLB.get(childIndex)[i];
            }
            lbList[i] = lb;
        }
    }

    private void sendCostMessage(AdoptCostMessage cost) {
        Message message = new Message(this.id,parent,TYPE_COST_MESSAGE,cost);
        sendMessage(message);
    }

    private void sendTerminateMessage(HashMap<Integer, Integer> parContext) {
        for (int childIndex:children) {
            Message message  = new Message(this.id,childIndex,TYPE_TERMINATE_MESSAGE,parContext);
            sendMessage(message);
        }
    }

    private void maintanAllocationInvariant() {
    }

    private void sendValueMessage(int value) {
        for (int pChildIndex:pseudoChildren) {
            Message message = new Message(this.id,pChildIndex,TYPE_VALUE_MESSAGE,value);
            sendMessage(message);
        }
    }

    private int getValueIndex() {
        int tempLB = Integer.MAX_VALUE;//初值是最大值还是UB？
        int tempValue = -1;
        for (int childIndex:children) {
            for (int i = 0; i < domain.length; i++) {
                if (calLocalCost(i)<tempLB){
                    tempLB = calLocalCost(i);
                    tempValue = i;
                }
            }
        }
        return tempValue;
    }

    private int calLocalCost(int value) {
        int cost = 0;
        for (int neichildIndex:currentContext.keySet()) {
            cost += constraintCosts.get(neichildIndex)[value][currentContext.get(neichildIndex)];
        }
        return cost;
    }


    @Override
    public Object printResults(List<Map<String, Object>> results) {
        return null;
    }

    @Override
    public String easyMessageContent(Message msg, Agent sender, Agent receiver) {
        return null;
    }

    @Override
    protected void disposeMessage(Message msg) {
        switch (msg.getType()){
            case TYPE_VALUE_MESSAGE:
                disposeValueMessage(msg);
                break;
            case TYPE_COST_MESSAGE:
                disposeCostMessage(msg);
                break;
            case TYPE_THRESHOLD_MESSAGE:
                disposeThresholdMessage(msg);
                break;
            case TYPE_TERMINATE_MESSAGE:
                disposeTerminateMessage(msg);
                break;
        }
    }

    @SuppressWarnings("unchecked")
    private void disposeTerminateMessage(Message msg) {
        isTerminate = true;
        currentContext = (HashMap<Integer, Integer>) msg.getValue();
        backTrack();
    }

    private void disposeThresholdMessage(Message msg) {
    }

    private void disposeCostMessage(Message msg) {
    }

    private void disposeValueMessage(Message msg) {
        if (!isTerminate){
            currentContext.put(msg.getIdSender(), (Integer) msg.getValue());
            for (int i = 0; i < childrenContext.size(); i++) {

            }
        }
    }

    @Override
    protected void messageLost(Message msg) {

    }


}
