package com.cqu.heuristics;

public class DFSHeuristicsManager {
	public static final String[] HEURISTICS_TYPES=new String[]{"MostConnected", "MostConstribution", "LeastConnected", "RandScoring"};
}
