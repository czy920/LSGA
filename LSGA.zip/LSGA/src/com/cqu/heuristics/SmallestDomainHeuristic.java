package com.cqu.heuristics;

public class SmallestDomainHeuristic {

}
