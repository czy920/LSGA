package com.cqu.core;

public class AcoResultCycle extends ResultCycle {
    public double[] acobestCostInCycle;

    public AcoResultCycle(double[] acobestCostInCycle) {
        this.acobestCostInCycle = acobestCostInCycle;
    }

    public AcoResultCycle(Result rs, double[] acobestCostInCycle) {
        super(rs);
        this.acobestCostInCycle = acobestCostInCycle;
    }
}
