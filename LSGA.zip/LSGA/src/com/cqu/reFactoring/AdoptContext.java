package com.cqu.reFactoring;

import java.util.HashMap;

public class AdoptContext {
    private HashMap<Integer,Integer> context;

    public AdoptContext(HashMap<Integer, Integer> context) {
        this.context = context;
    }
}
