package com.cqu.reFactoring;

import com.cqu.core.*;
import org.omg.PortableInterceptor.INACTIVE;

import java.util.*;

public class ADOPTAgent extends Agent {

    public final static int MSG_TYPE_VALUE = 201;
    public final static int MSG_TYPE_COST = 202;
    public final static int MSG_TYPE_THRESHOLD = 203;
    public final static int MSG_TYPE_TERMINATE = 204;

    public final static String KEY_CONTEXT="KEY_CONTEXT";
    public final static String KEY_LB="KEY_LB";
    public final static String KEY_UB="KEY_UB";
    public final static String KEY_TH="KEY_TH";
    public final static String KEY_NCCC="KEY_NCCC";

    private int threshold;
    private int bigLB;
    private int bigUB;
    private int currentLB;
    private boolean isTerminate;
    private HashMap<Integer,int[]> childLB;
    private HashMap<Integer,int[]> childUB;
    private HashMap<Integer,int[]> childThreshold;
    private Context currentContext;
    private HashMap<Integer,Context[]> context;

    public ADOPTAgent(int id, String name, int level, int[] domain) {
        super(id, name, level, domain);
        childLB = new HashMap<Integer, int[]>();
        childUB = new HashMap<Integer, int[]>();
        childThreshold = new HashMap<Integer, int[]>();
        currentContext = new Context();
        context = new HashMap<Integer, Context[]>();
    }

    @Override
    protected void initRun() {
        super.initRun();
        threshold = 0;
        bigLB = 0;
        currentLB = 0;
        bigUB = Integer.MAX_VALUE;
        for (int childId:children) {
            int[] childLBs = new int[domain.length];
            int[] childUBs = new int[domain.length];
            int[] childTHs = new int[domain.length];
            Context[] childContexts = new Context[domain.length];
            for (int i = 0; i < domain.length; i++) {
                childLBs[i] = 0;
                childUBs[i] = Integer.MAX_VALUE;
                childTHs[i] = 0;
                childContexts[i] = new Context();
            }
            childLB.put(childId,childLBs);
            childUB.put(childId,childUBs);
            childThreshold.put(childId,childTHs);
            context.put(childId,childContexts);
        }
        valueIndex = makeDeceisionByLB();

        backTrack();
    }

    private int makeDeceisionByLB() {
        int value = valueIndex;//?
        int tempLB = Integer.MAX_VALUE;
        for (int i = 0; i < domain.length; i++) {
            int lb = 0;
            for (int childId:children) {
                lb += childLB.get(childId)[i];
            }
            if (lb < tempLB){
                tempLB = lb;
                value = i;
            }
        }
        return value;
    }

    private int makeDeceisionByUB() {
        int value = valueIndex;//?
        int tempUB = Integer.MAX_VALUE;
        for (int i = 0; i < domain.length; i++) {
            int ub = 0;
            for (int childId:children) {
                ub += childUB.get(childId)[i];
            }
            if (ub < tempUB){
                tempUB = ub;
                value = i;
            }
        }
        return value;
    }

    private void backTrack() {

        updateInfo(); //更新bigLB, bigUB, currentLB
        if (threshold == bigUB){
            valueIndex = makeDeceisionByUB();
        }else if (currentLB > threshold){
            valueIndex = makeDeceisionByLB();
        }
        sendValueMessage(valueIndex);
        maintainAllocationInvariant();
        if (threshold == bigUB){
            if (isTerminate||isRootAgent()){
                sendTerminateMessage();
                stopRunning();
            }
        }
        sendCostMessage(currentContext,bigLB,bigUB);
    }

    private void sendCostMessage(Context con, int lb, int ub) {
        if(isRootAgent())
        {
            return;
        }
        HashMap<String,Object> costMsg = new HashMap<>();
        costMsg.put(ADOPTAgent.KEY_CONTEXT,con);
        costMsg.put(ADOPTAgent.KEY_LB,lb);
        costMsg.put(ADOPTAgent.KEY_UB,ub);
        Message message = new Message(this.id,this.parent,MSG_TYPE_COST,costMsg);
        sendMessage(message);

    }

    private void sendTerminateMessage() {
        if (isLeafAgent()){
            return;
        }
        Context con = currentContext;
        con.addOrUpdate(this.id,valueIndex);
        for (int childId:children) {
            Message message = new Message(this.id,childId,MSG_TYPE_TERMINATE,con);
            sendMessage(message);
        }
    }

    private void maintainAllocationInvariant() {
        if (this.isLeafAgent()){
            return;
        }
        int diff = this.threshold - calcuTH(valueIndex);
        int diffOriginalValue = diff;
        if (diff > 0){
            while (diff != 0){
                diffOriginalValue = diff;
                for (int childId:children) {
                    int availDiff = Infinity.minus(this.childLB.get(childId)[valueIndex],this.childThreshold.get(childId)[valueIndex]);
                    if (availDiff > 0){
                        if ((diff - availDiff) <= 0){
                            this.childThreshold.get(childId)[valueIndex] = Infinity.add(this.childThreshold.get(childId)[valueIndex],diff);
                            diff = 0;
                            break;
                        }else {
                            this.childThreshold.get(childId)[valueIndex]=Infinity.add(this.childThreshold.get(childId)[valueIndex],availDiff);
                            diff=Infinity.minus(diff, availDiff);
                        }
                    }
                }
                if(diff == diffOriginalValue)
                {
                    break;//无法使diff为0，也退出
                }
            }
        }else if(diff<0)
        {
            while(diff!=0)
            {
                diffOriginalValue=diff;
                for(int i=0;i<this.children.length;i++)
                {
                    int childId = this.children[i];
                    int availDiff = Infinity.minus(this.childThreshold.get(childId)[valueIndex], this.childLB.get(childId)[valueIndex]);
                    if(availDiff>0)
                    {
                        if((diff+availDiff)>=0)
                        {
                            this.childThreshold.get(childId)[valueIndex] = Infinity.minus(this.childThreshold.get(childId)[valueIndex], diff);
                            diff = 0;
                            break;
                        }else
                        {
                            this.childThreshold.get(childId)[valueIndex] = Infinity.minus(this.childThreshold.get(childId)[valueIndex], availDiff);
                            diff = Infinity.add(diff, availDiff);
                        }
                    }
                }
                if(diff==diffOriginalValue)
                {
                    break;//无法使diff为0，也退出
                }
            }
        }
        sendThresholdMessage(childThreshold,currentContext);
    }

    private void sendThresholdMessage(HashMap<Integer,int[]> threshold, Context context) {
        if (isLeafAgent()){
            return;
        }
        for (int childId:children) {
            HashMap<String,Object> threMsg = new HashMap<>();
            threMsg.put(ADOPTAgent.KEY_CONTEXT,context);
            threMsg.put(ADOPTAgent.KEY_TH,threshold.get(childId)[valueIndex]);
            Message message = new Message(this.id,childId,MSG_TYPE_THRESHOLD,threMsg);
            sendMessage(message);
        }
    }


    private int calcuTH(int value) {
        int th = calcuCost(value);
        for (int childId:children) {
            th += childThreshold.get(childId)[value];
        }
        return th;
    }

    private int calcuCost(int value) {
        int cost = 0;
        if (isRootAgent()){
            return 0;
        }

        int parentId = 0;
        int oppositeAgentValueIndex = 0;
        for(int i=0;i<this.currentContext.size();i++)
        {
            oppositeAgentValueIndex = currentContext.get(i);
            if(oppositeAgentValueIndex==-1 )
            {
                cost += 0;
            }else
            {
                cost += this.constraintCosts.get(parentId)[value][oppositeAgentValueIndex];
            }
        }
        return cost;
    }

    private void sendValueMessage(int value) {
        for (int childId:allChildren) {
            Message message = new Message(this.id,childId,MSG_TYPE_VALUE,value);
            sendMessage(message);
        }
    }

    private int calcuLB(int value) {
        int lb = 0;
        for (int childId:children) {
            lb += childLB.get(childId)[value];
        }
        return lb;
    }

    private void updateInfo() {
        int tempLB = Integer.MAX_VALUE;
        int tempUB = Integer.MAX_VALUE;
        if (isLeafAgent()){
            currentLB = calcuCost(valueIndex);
            int lb = 0;
            int ub = 0;
            for (int i = 0; i < domain.length; i++) {
                lb = calcuCost(i);
                if (lb < tempLB){
                    tempLB = lb;
                }
                ub = calcuCost(i);
                if (ub < tempUB){
                    tempUB = ub;
                }
            }
        }else {
            for (int i = 0; i < domain.length; i++) {
                int lb = 0;
                int ub = 0;
                for (int childId:children) {
                    lb += childLB.get(childId)[i];
                    ub += childUB.get(childId)[i];
                }
                if (lb < tempLB){
                    tempLB = lb;
                }
                if (ub < tempLB){
                    tempUB = lb;
                }
            }
        }
        this.bigLB = tempLB;
        this.bigUB = tempUB;
    }

    @Override
    public String easyMessageContent(Message msg, Agent sender, Agent receiver) {
        return null;
    }

    @Override
    protected void disposeMessage(Message msg) {
//        System.out.println("Dispose Message:   " + this.name + "receive a " + msg.getType() + "  from   Agent: " + msg.getIdSender());
        switch (msg.getType()){
            case MSG_TYPE_VALUE:
                disposeValueMessage(msg);
                break;
            case MSG_TYPE_COST:
                disposeCostMessage(msg);
                break;
            case MSG_TYPE_THRESHOLD:
                disposeThresholdMessage(msg);
                break;
            case MSG_TYPE_TERMINATE:
                System.out.println("terminate!!!");
                disposeTerminateMessage(msg);
                break;
        }
    }

    private void disposeValueMessage(Message msg) {
        if (!isTerminate){
            currentContext.addOrUpdate(msg.getIdSender(), (Integer) msg.getValue());
            checkCompatible();
            maintainThresholdInvariant();
            backTrack();
        }
    }

    private void checkCompatible() {
        if (isLeafAgent()){
            return;
        }
        for (int j = 0; j < children.length; j++) {
            for (int i = 0; i < domain.length; i++) {
                int childId = children[j];
                if (!context.get(childId)[i].recompatible(currentContext)){
                    childLB.get(childId)[i] = 0;
                    childThreshold.get(childId)[i] = 0;
                    childUB.get(childId)[i] = Integer.MAX_VALUE;
                    context.get(childId)[i].reset();
                }
            }
        }
//        for (int childId:children) {
//            for (int i = 0; i < domain.length; i++) {
//                if (!context.get(childId)[i].compatible(currentContext)){
//                    childLB.get(childId)[i] = 0;
//                    childThreshold.get(childId)[i] = 0;
//                    childUB.get(childId)[i] = Integer.MAX_VALUE;
//                    context.get(childId)[i].reset();
//                }
//            }
//        }
    }

    private void maintainThresholdInvariant() {
        if (this.threshold < this.bigLB){
            threshold = bigLB;
        }
        if (this.threshold > this.bigUB){
            threshold = bigUB;
        }
    }

    private void disposeCostMessage(Message msg) {
        Map<String,Object> costMsg = (Map<String, Object>) msg.getValue();
        Context reCon = (Context) costMsg.get(ADOPTAgent.KEY_CONTEXT);
        int d = reCon.get(this.id);
        reCon.remove(this.id);

        if (!isTerminate){
            merge(reCon);
            checkCompatible();
        }
        if (!reCon.compatible(currentContext)){
            childUB.get(msg.getIdSender())[d] = (int) costMsg.get(ADOPTAgent.KEY_UB);
            childLB.get(msg.getIdSender())[d] = (int) costMsg.get(ADOPTAgent.KEY_LB);
            context.get(msg.getIdSender())[d] = (Context) costMsg.get(ADOPTAgent.KEY_CONTEXT);
            maintainChildThresholdInvariant();
            maintainThresholdInvariant();
        }
        backTrack();
    }

    private void maintainChildThresholdInvariant() {
        for (int childId:children) {
            for (int i = 0; i < domain.length; i++) {
                if (childLB.get(childId)[i] > childThreshold.get(childId)[i]){
                    childThreshold.get(childId)[i] = childLB.get(childId)[i];
                }
                if (childThreshold.get(childId)[i] > childUB.get(childId)[i]){
                    childThreshold.get(childId)[i] = childUB.get(childId)[i];
                }
            }
        }
    }

    private void merge(Context reCon) {
        Context temp=new Context(reCon);
        temp.remove(this.neighbours);
        currentContext.union(temp);
    }


    private void disposeThresholdMessage(Message msg) {
        Map<String,Object> thMsg = (Map<String, Object>) msg.getValue();
        Context reCon = (Context) thMsg.get(ADOPTAgent.KEY_CONTEXT);
        int th = (int) thMsg.get(ADOPTAgent.KEY_TH);
        if (reCon.compatible(currentContext)){
            this.threshold = th;
            maintainThresholdInvariant();
            backTrack();
        }
    }

    private void disposeTerminateMessage(Message msg) {
        currentContext = (Context) msg.getValue();
        backTrack();
    }

    @Override
    public Object printResults(List<Map<String, Object>> results) {
        // TODO Auto-generated method stub
        int totalCost=-1;
        for(Map<String, Object> result : results)
        {
            int id_=(Integer) result.get(ADOPTAgent.KEY_ID);
            String name_=(String) result.get(ADOPTAgent.KEY_NAME);
            int value_=(Integer) result.get(ADOPTAgent.KEY_VALUE);
            int LB_=(Integer) result.get(ADOPTAgent.KEY_LB);
            int UB_=(Integer) result.get(ADOPTAgent.KEY_UB);
            int TH_=(Integer) result.get(ADOPTAgent.KEY_TH);
            if(totalCost<UB_)
            {
                totalCost=UB_;
            }
            String displayStr="Agent "+name_+": id="+id_+" value="+value_+" LB="+LB_+" UB=";
            displayStr+=Infinity.infinityEasy(UB_);
            displayStr+=" TH="+Infinity.infinityEasy(TH_);
            System.out.println(displayStr);
        }
        System.out.println("totalCost: "+Infinity.infinityEasy(totalCost));
        ResultAdopt ret=new ResultAdopt();
        ret.totalCost=totalCost;
        return ret;
    }

    @Override
    protected void runFinished() {
        super.runFinished();

        Map<String, Object> result=new HashMap<String, Object>();
        result.put(ADOPTAgent.KEY_ID, this.id);
        result.put(ADOPTAgent.KEY_NAME, this.name);
        result.put(ADOPTAgent.KEY_VALUE, this.domain[valueIndex]);
        result.put(ADOPTAgent.KEY_LB, this.bigLB);
        result.put(ADOPTAgent.KEY_UB, this.bigUB);
        result.put(ADOPTAgent.KEY_TH, this.threshold);

        this.msgMailer.setResult(result);
        System.out.println("Agent "+this.name+" stopped!");
    }

    @Override
    protected void messageLost(Message msg) {

    }
}
