package com.cqu.reFactoring;

import java.util.HashMap;

public class ADOPTCostMessage {
    private int childLB;
    private int childUB;
    private HashMap<Integer,Integer> childCurrrentContext;

    public ADOPTCostMessage(int childLB, int childUB, HashMap<Integer, Integer> childCurrrentContext) {
        this.childLB = childLB;
        this.childUB = childUB;
        this.childCurrrentContext = childCurrrentContext;
    }

    public int getChildLB() {
        return childLB;
    }

    public void setChildLB(int childLB) {
        this.childLB = childLB;
    }

    public int getChildUB() {
        return childUB;
    }

    public void setChildUB(int childUB) {
        this.childUB = childUB;
    }

    public HashMap<Integer, Integer> getChildCurrrentContext() {
        return childCurrrentContext;
    }

    public void setChildCurrrentContext(HashMap<Integer, Integer> childCurrrentContext) {
        this.childCurrrentContext = childCurrrentContext;
    }
}
