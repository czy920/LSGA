package com.cqu.reFactoring;

import java.util.HashMap;

public class ADOPTThresholdMsg {
    private HashMap<Integer,Integer> childThreshold;
    private HashMap<Integer,Integer> currentContext;

    public ADOPTThresholdMsg(HashMap<Integer, Integer> childThreshold, HashMap<Integer, Integer> currentContext) {
        this.childThreshold = childThreshold;
        this.currentContext = currentContext;
    }

    public HashMap<Integer, Integer> getChildThreshold() {
        return childThreshold;
    }

    public void setChildThreshold(HashMap<Integer, Integer> childThreshold) {
        this.childThreshold = childThreshold;
    }

    public HashMap<Integer, Integer> getCurrentContext() {
        return currentContext;
    }

    public void setCurrentContext(HashMap<Integer, Integer> currentContext) {
        this.currentContext = currentContext;
    }
}
