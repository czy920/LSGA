package com.cqu.reFactoring;

import com.cqu.core.*;
import com.cqu.core.Solver.BatSolveListener;

public class TEST {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
//        Solver solver = new Solver();
//        solver.batSolve("E:\\DCOP\\problems\\new_problem\\0.6", "reADOPT", 30, new EventListener() {
//
//            @Override
//            public void onStarted() {
//                // TODO Auto-generated method stub
//            }
//
//            @Override
//            public void onFinished(Object result) {
//                // TODO Auto-generated method stub
//
//            }
//        }, new BatSolveListener() {
//
//            public void progressChanged(int problemTotalCount, int problemIndex, int timeIndex) {
//                // TODO Auto-generated method stub
//
//            }
//        });

		Solver solver = new Solver();
		solver.solve("E:\\DCOP\\problems\\tiny_Test\\RandomDCOP_10_10_1.xml",
				"reADOPT", false, false, new EventListener() {

					@Override
					public void onStarted() {
						// TODO Auto-generated method stub

					}

					@Override
					public void onFinished(Object result) {

						// TODO Auto-generated method stub
//						ResultCycleAls resultCycleAls = (ResultCycleAls) result;
//		                for (int i = 0; i < resultCycleAls.bestCostInCycle.length; i++){
//		                    System.out.println( i + "\t" + resultCycleAls.bestCostInCycle[i]);
//
//		                }

                        Result adoptResult = (Result) result;
                        System.out.println(((Result) result).totalCost);
					}
				});

    }
}

