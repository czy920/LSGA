package com.cqu.test;



import java.util.Scanner;

public class test {
public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    int C = scanner.nextInt();
    int[] a = new int[C];
    for(int i=0; i < C; i++){
        int n = scanner.nextInt();
        int[] b = new int[n];
            for(int j = 0; j<n; j++){
                b[j] = scanner.nextInt();
            }
            int s1=b[0],s2=b[0];
            for(int k = 1; k < n; k++){
                if(b[k] < s1){
                    s2 =s1;
                    s1 = b[k];
                }
                if( b[k] > s1 && b[k] <= s2){
                    s2 = b[k];
                }
                if(s1 == s2 && b[k]> s1) {
                    s2 = b[k];
                }
                }
                if(s1 == s2) {
                    a[i] = 999;
                }
            else {
                a[i] = s2;
            }
        }
        for(int i=0; i < C-1; i++){
            if(a[i]==999){
                System.out.println("NO");
            }
            else{
                System.out.println(a[i]);
            }
        }
        if(a[C-1]==999){
            System.out.println("NO");
        }
        else{
            System.out.println(a[C-1]);
        }
        scanner.close();
    }
}


