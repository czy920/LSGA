package com.cqu.test;
import java.util.Scanner;

public class test2 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            int n = scanner.nextInt();
        if(n<=1000){
            System.out.print(fun(n)+1);
            }
        }
        public static int fun(int n) {
                if(n==1) {
                    return 0;
                }
                return (fun(n-1)+3)%n;
        }
}
