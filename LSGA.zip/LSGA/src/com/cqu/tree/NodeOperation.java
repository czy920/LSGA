package com.cqu.tree;

/**
 * 节点操作
 * @author hz
 *
 */
public interface NodeOperation {
	
	void operate(Integer curNodeId);
}
