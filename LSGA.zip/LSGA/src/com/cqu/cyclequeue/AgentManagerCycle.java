package com.cqu.cyclequeue;

import java.util.HashMap;


import java.util.List;
import java.util.Map;

import com.cqu.aco.AcoAgent;
import com.cqu.acoAAAI.ACOaaaiAgent;
import com.cqu.adopt.AdoptAgentCycle;
import com.cqu.adopt.AdoptAgentCycle_2;
import com.cqu.adpop.ADPOPAgent;
import com.cqu.bnbadopt.ADOPT_K;
import com.cqu.bnbadopt.BnBAdoptAgent;
import com.cqu.bnbmergeadopt.AgentModel;
import com.cqu.coopt.CooptAgent;
import com.cqu.core.Message;
import com.cqu.dsa.*;
import com.cqu.ga.*;
import com.cqu.gibbs.PDGibbs;
import com.cqu.gibbs.SDGibbs;
import com.cqu.maxsum.*;
import com.cqu.dsan.*;
import com.cqu.llz.*;
import com.cqu.mgm.*;
import com.cqu.mus.*;
import com.cqu.pds.*;
import com.cqu.parser.Problem;
import com.cqu.reWriter.SynchBBAgent;
import com.cqu.settings.Settings;
import com.cqu.util.CollectionUtil;
import com.cqu.util.FileUtil;

public class AgentManagerCycle {

    private Map<Integer, AgentCycle> agents;
	
	public AgentManagerCycle(Problem problem, String agentType) {
		// TODO Auto-generated constructor stub
		agents=new HashMap<Integer, AgentCycle>();
		for(Integer agentId : problem.agentNames.keySet())
		{
			AgentCycle agent=null;;
			if(agentType.equals("DPOP"))
			{
			}else if(agentType.equals("BNBADOPT"))
			{
				agent=new BnBAdoptAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
				
				/*int []domain = new int[problem.variableDomains.get(agentId).size()];
				Iterator<Integer> iter = problem.variableDomains.get(agentId).iterator();
				//System.out.println("agent:" + agentId);
				for (int i = 0; iter.hasNext();i++)
				{
					domain[i] = iter.next();
					
				}*/
				
	
				/*agent=new BnBAdoptAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.VariableDomains.get(agentId));
				
				BnBAdoptAgent.agentDomains.put(agentId, problem.VariableDomains.get(agentId));*/
				
			}
			else if(agentType.equals("BDADOPT")){
				agent=new AgentModel(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)),problem.treeDepth,problem.pseudoHeight);
			}
			else if(agentType.equals("ADOPT_K")){
				agent=new ADOPT_K(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)),Settings.settings.getADOPT_K());
			}
			else if(agentType.equals("SynAdopt2")){
				agent=new AdoptAgentCycle_2(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("DSA_A")){
				agent=new DsaA_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("DSA_B")){
				agent=new DsaB_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("DSA_C")){
				agent=new DsaC_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("DSA_D")){
				agent=new DsaD_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("DSA_E")){
				agent=new DsaE_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("ALS_DSA")){
				agent=new AlsDsa_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("DSAN")){
				agent=new DsanAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("MGM")){
				agent=new MgmAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("MGM2")){
				agent=new Mgm2Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			
			else if(agentType.equals("DSA_PPIRA")){
				agent=new DsaPPIRA_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("DSA_SDP")){
				agent=new DsaSDP_Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("ALSMLUDSA")){
				agent=new AlsMluDsaAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("ALSDSAMGM")){
				agent=new AlsDsaMgmAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("ALSDSAMGMEVO")){
				agent=new AlsDsaMgmEvoAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("ALSDSADSAEVO")){
				agent=new AlsDsaDsaEvoAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("ALSDGAFB")){
				agent=new AlsDgaFBAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("PDSALSDSA")){
				agent=new Pds_AlsDsaAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("PDSDSAN")){
				agent=new Pds_DsanAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("PDSDSASDP")){
				agent=new Pds_DsaSdpAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("PDSMGM")){
				agent=new Pds_MgmAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("PDSMGM2")){
				agent=new Pds_Mgm2Agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if(agentType.equals("ACO")||agentType.equals("ACO_tree")||agentType.equals("ACO_bf")||agentType.equals("ACO_phase")||
					agentType.equals("ACO_line")||agentType.equals("ACO_final")){
				agent=new AcoAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)), problem.treeDepth);
			}
			else if (agentType.equals("MAXSUM")) {
				agent=new MaxSumAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("MAXSUMAD")) {
				agent=new MaxSumADAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("MAXSUMRS")) {
				agent=new MaxSumRefineStructureAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
//			else if (agentType.equals("MAXSUMSPLITED")) {
//				agent=new SplitedMaxSumAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
//						problem.domains.get(problem.agentDomains.get(agentId)));
//			}
			else if (agentType.equals("SBB")) {
				agent=new SynchBBAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("MAXSUMOH")) {
				agent=new MaxSumOneHotAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("MGM2_AL")) {
				agent=new MGM2_9(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("DSA_AL")) {
				agent=new DSA_A2agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("ALS_DSA_SDP")) {
				agent=new Dsa_sdp(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("AnytimeDsa")) {
				agent=new AlsDsa(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
				
			}
			else if (agentType.equals("mals")) {
				agent=new mals_agent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("SDPAnytime")) {
				agent=new sdp_malsAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("LS_GA")) {//不加竞争机制
				agent=new LS_GA(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("AlsDga")) {//mus中的DGA
				agent=new AlsDgaAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGA")) {//加了竞争机制的LS_GA，竞争过程中不停dsa
				agent=new FB_LSGA(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("FBwithoutALS")) {//不加anyTime框架的FB_LSGA
				agent=new FBwithoutALS(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("DgaFb")) {//mus中的FBDGA
				agent=new AlsDgaFBAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGA2")) {//FB_LSGA在竞争过程中停DSA
				agent=new FB_LSGA2(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_Mgm")) {
				agent=new FB_MGM(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("FBwithoutALS")) {
				agent=new FBwithoutALS(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGArou")) {
				agent=new FB_LSGArou(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGArouMed")) {
				agent=new FB_LSGArouMed(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGArou2")) {
				agent=new FB_LSGArou2(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGArouwithoutALS")) {
				agent=new FB_LSGArou2withoutALS(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGArou3")) {
				agent=new FB_LSGArou3(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("Fb_LSGArouMedrouMu")) {
				agent=new FB_LSGArouMedrouMu(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("MGM2_test")) {
				agent=new mgm2(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("amgm")) {
				agent=new mgm(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("sdp_dsaAL")) {
				agent=new Dsa_sdp(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("GDBA")) {
				agent=new AlsGdbaAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("FB_mgm2")) {
				agent=new FB_MGM2(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("GA_dsa")) {
				agent=new ga_dsa(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("GA_dgba")) {
				agent=new ga_dgba(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("reGDBA_ALS")) {
				agent=new gdba_als(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("LSGA_tree")) {
				agent=new lsgaTree(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			/////////////////重写代码的测试函数///////////////////////
			else if (agentType.equals("reDSA")) {
				agent=new DsaAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("reALSDSA")) {
				agent=new ALSDsaAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("M_DSA")) {
				agent=new MDsaAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
		    else if (agentType.equals("reLSGA")) {
			agent=new LSGAAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
					problem.domains.get(problem.agentDomains.get(agentId)));
		    }
			else if (agentType.equals("LSGAroulette")) {
				agent=new LSGADSArouletteAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("LSGAchampion")) {
				agent=new LSGAchampionAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("M_SDP")) {
				agent=new MSdpAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("M_MGM")) {
				agent=new MMGMAgentCycle(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("LSGA_MGM")) {
				agent=new LSGAMGMAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("LSGA_MGMroulette")) {
				agent=new LSGAMGMroulette(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("M_GDBA")) {
				agent=new MGDBAAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("ALS_GDBA")) {
				agent=new ALSGDBAAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
			else if (agentType.equals("LSGA_MGM2")) {
				agent=new MMGM2(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
						problem.domains.get(problem.agentDomains.get(agentId)));
			}
            else if (agentType.equals("re_SBB")) {
                agent=new SynchBBAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("LSGA_MGM2rou")) {
                agent=new LSGAMGM2roulette(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("LSGAGDBA")) {
                agent=new LSGAGDBA(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("LSGArouletteNei")){
                agent=new LSGArouletteNeiAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("ACOaaai")){
                agent=new ACOaaaiAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("cooptAgent")){
                agent=new CooptAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("SD_Gibbs")){
                agent=new SDGibbs(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("PD_Gibbs")){
                agent=new PDGibbs(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
            else if (agentType.equals("ADPOP")){
                agent=new ADPOPAgent(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId),
                    problem.domains.get(problem.agentDomains.get(agentId)));
            }
			else{
				agent=new AdoptAgentCycle(agentId, problem.agentNames.get(agentId), problem.agentLevels.get(agentId), 
						problem.domains.get(problem.agentDomains.get(agentId)));
			}

			Map<Integer, int[]> neighbourDomains=new HashMap<Integer, int[]>();
			Map<Integer, int[][]> constraintCosts=new HashMap<Integer, int[][]>();
			int[] neighbourAgentIds=problem.neighbourAgents.get(agentId);
			Map<Integer, Integer> neighbourLevels=new HashMap<Integer, Integer>();
			for(int i=0;i<neighbourAgentIds.length;i++)
			{
				neighbourDomains.put(neighbourAgentIds[i], problem.domains.get(problem.agentDomains.get(neighbourAgentIds[i])));
				neighbourLevels.put(neighbourAgentIds[i], problem.agentLevels.get(neighbourAgentIds[i]));
			}
			String[] neighbourAgentCostNames=problem.agentConstraintCosts.get(agentId);
			for(int i=0;i<neighbourAgentCostNames.length;i++)
			{
				if(agentId < neighbourAgentIds[i]){
					constraintCosts.put(neighbourAgentIds[i], 
							CollectionUtil.toTwoDimension(problem.costs.get(neighbourAgentCostNames[i]), 
									problem.domains.get(problem.agentDomains.get(agentId)).length, 
									problem.domains.get(problem.agentDomains.get(neighbourAgentIds[i])).length));
				}else{
					int[][] temp = CollectionUtil.toTwoDimension(problem.costs.get(neighbourAgentCostNames[i]), 
							problem.domains.get(problem.agentDomains.get(neighbourAgentIds[i])).length, 
							problem.domains.get(problem.agentDomains.get(agentId)).length);
					
					constraintCosts.put(neighbourAgentIds[i], CollectionUtil.reverse(temp));
				}
			}
			
			if(agentType.equals("ACO")||agentType.equals("ACO_tree")||agentType.equals("ACO_bf")||agentType.equals("ACO_phase")||
					agentType.equals("ACO_line")||agentType.equals("ACO_final")||agentType.equals("SBB")){
				agent.setNeibours(problem.neighbourAgents.get(agentId), problem.parentAgents.get(agentId), 
						problem.childAgents.get(agentId), problem.allParentAgents.get(agentId), 
						problem.allChildrenAgents.get(agentId), neighbourDomains, constraintCosts, neighbourLevels,
						problem.highNodes.get(agentId),problem.lowNodes.get(agentId), problem.priorities.get(agentId), problem.allNodes, problem.maxPriority, problem.minPriority);
			}else{
				agent.setNeibours(problem.neighbourAgents.get(agentId), problem.parentAgents.get(agentId), 
						problem.childAgents.get(agentId), problem.allParentAgents.get(agentId), 
						problem.allChildrenAgents.get(agentId), neighbourDomains, constraintCosts, neighbourLevels);
			}		
			
			agents.put(agent.getId(), agent);
			
			AgentCycle.totalHeight = 0;
			for(AgentCycle tempAgent : agents.values()){
				if(AgentCycle.totalHeight < tempAgent.level)
					AgentCycle.totalHeight = tempAgent.level;
			}
			
			{
				String str="-----------"+agent.name+"-----------\n";
				str+="Parent: "+agent.parent+"\n";
				str+="Children: "+CollectionUtil.arrayToString(agent.children)+"\n";
				str+="AllParents: "+CollectionUtil.arrayToString(agent.allParents)+"\n";
				str+="AllChildren: "+CollectionUtil.arrayToString(agent.allChildren)+"\n";
				FileUtil.writeStringAppend(str, "dfsTree.txt");
			}
		}//for
	}
	
	public AgentCycle getAgent(int agentId)
	{
		if(agents.containsKey(agentId))
		{
			return agents.get(agentId);
		}else
		{
			return null;
		}
	}
	
	public Map<Integer, Integer> getAgentValues()
	{
		Map<Integer, Integer> agentValues=new HashMap<Integer, Integer>();
		for(AgentCycle agent : agents.values())
		{
			agentValues.put(agent.getId(), agent.getValue());
		}
		return agentValues;
	}
	
	public Map<Integer, AgentCycle> getAgents()
	{
		return this.agents;
	}
	
	public int getAgentCount()
	{
		return this.agents.size();
	}
	
	public void startAgents(MessageMailerCycle msgMailer)
	{
		for(AgentCycle agent : agents.values())
		{
			agent.setMessageMailer(msgMailer);
			agent.startProcess();
		}
	}
	
	public void stopAgents()
	{
		for(AgentCycle agent : agents.values())
		{
			agent.stopRunning();
		}
	}
	
	public Object printResults(List<Map<String, Object>> results)
	{
		if(results.size()>0)
		{
			AgentCycle agent=null;
			for(Integer agentId : this.agents.keySet())
			{
				agent=this.agents.get(agentId);
				break;
			}
			return agent.printResults(results);
		}
		return null;
	}
	
	public String easyMessageContent(Message msg)
	{
		AgentCycle senderAgent=this.getAgent(msg.getIdSender());
		AgentCycle receiverAgent=this.getAgent(msg.getIdReceiver());
		return senderAgent.easyMessageContent(msg, senderAgent, receiverAgent);
	}
	
	public int getTotalCost(){
		int totalCost = 0;
		for(AgentCycle agent : agents.values()){
			if(agent != null)
				totalCost += agent.getLocalCost();
		}
		totalCost = totalCost/2;
		return totalCost;
	}
	
}
