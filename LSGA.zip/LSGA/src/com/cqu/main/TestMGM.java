package com.cqu.main;

import com.cqu.core.EventListener;
import com.cqu.core.ResultCycle;
import com.cqu.core.Solver;


public class TestMGM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Solver solver=new Solver();
		solver.solve("E:\\DCOP\\problems\\new_problem\\0.1\\RandomDCOP_120_10_10.xml", "amgm", false, false, new EventListener() {
			@Override
			public void onStarted() {
				// TODO Auto-generated method stub
			}
			@Override
			public void onFinished(Object result) {
				// TODO Auto-generated method stub
				ResultCycle resultCycle = (ResultCycle)result;
				for (int i = 0; i < resultCycle.totalCostInCycle.length;i++){
					System.out.println((i + 1) + "\t" + resultCycle.totalCostInCycle[i]);
				}
			}
		});
	}
}
