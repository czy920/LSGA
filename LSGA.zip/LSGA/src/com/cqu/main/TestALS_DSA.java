package com.cqu.main;

import com.cqu.core.EventListener;

import com.cqu.core.ResultCycle;
import com.cqu.core.Solver;
import com.cqu.settings.Settings;

public class TestALS_DSA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Settings.settings.setCycleCount(100);
        Settings.settings.setDisplayGraphFrame(false);
		
		Solver solver = new Solver();
		solver.solve("C:\\Users\\Administrator.UE8E6XNMLQRIGS8\\Desktop\\problems\\5\\RandomDCOP_120_10_1.xml", "ALS_DSA", false, false, new EventListener() {
			
			@Override
			public void onStarted() {
				// TODO Auto-generated method stub				
			}
			
			@Override
			public void onFinished(Object result) {
				// TODO Auto-generated method stub
				ResultCycle resultCycle = (ResultCycle)result;
				for (int i = 0; i < resultCycle.totalCostInCycle.length;i++){
					System.out.println((i + 1) + "\t" + resultCycle.totalCostInCycle[i]);
				}
			}
		});
	}

}
