package com.cqu.main;

import java.util.Map;

import com.cqu.core.EventListener;
import com.cqu.core.Infinity;
import com.cqu.core.ResultCycle;
import com.cqu.core.ResultCycleAls;
import com.cqu.core.Solver;
import com.cqu.llz.AlsAgentCycle;
import com.cqu.settings.Settings;

public class TestMGM2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Settings.settings.setCycleCount(100);
        Settings.settings.setDisplayGraphFrame(false);
		
		Solver solver = new Solver();
		
		solver.solve("E:\\\\DCOP\\\\problems\\\\new_problem\\\\0.1\\\\RandomDCOP_120_10_10.xml", "es", false, false, new EventListener() {
			
			@Override
			public void onStarted() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onFinished(Object result) {
				// TODO Auto-generated method stub
//				ResultCycle resultCycle = (ResultCycle)result;
//				for (int i = 0; i < resultCycle.totalCostInCycle.length;i++){
//					System.out.println((i + 1) + "\t" + resultCycle.totalCostInCycle[i]);
//				}
				
				ResultCycle resultCycle = (ResultCycle)result;
				System.out.println("************DSA***************");
				for (int i = 0; i < resultCycle.totalCostInCycle.length; i++) {
					System.out.println((i + 1) + "\t" + resultCycle.totalCostInCycle[i]);
				}
				
				
//				ResultCycleAls resultCycle = (ResultCycleAls)result;
//				for (int i = 0; i < resultCycle.totalCostInCycle.length; i++) {
//					System.out.println((i + 1) + "\t" + resultCycle.totalCostInCycle[i]);
//				}
			}
			
		});
	}

}
