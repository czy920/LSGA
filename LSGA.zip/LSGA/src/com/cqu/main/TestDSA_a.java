package com.cqu.main;

import com.cqu.core.EventListener;
import com.cqu.core.ResultCycle;
import com.cqu.core.Solver;
import com.cqu.settings.Settings;

public class TestDSA_a {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Solver solver=new Solver();
		solver.solve("C:\\Users\\Administrator.UE8E6XNMLQRIGS8\\Desktop\\问题\\20\\RandomDCOP_20_10_1.xml", "DSA_AL", false, false, new EventListener() {
			
			@Override
			public void onStarted() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onFinished(Object result) {
				// TODO Auto-generated method stub
				ResultCycle resultCycle = (ResultCycle)result;
				for (int i = 0; i < resultCycle.totalCostInCycle.length;i++){
					System.out.println((i + 1) + "\t" + resultCycle.totalCostInCycle[i]);
				}
			}
		});

	}

}
