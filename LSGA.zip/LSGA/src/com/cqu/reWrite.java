package com.cqu;

import com.cqu.core.Message;
import com.cqu.cyclequeue.AgentCycle;

import java.util.List;
import java.util.Map;



public class reWrite extends AgentCycle {
    public final static int TYPE_PREV_MSG = 201;
    public final static int TYPE_NEXT_MSG = 202;
    private int upperBound;
    private int valueCount;
    private int nextAgent;
    private int accCost;
    public reWrite(int id, String name, int level, int[] domain) {
        super(id, name, level, domain);
    }

    @Override
    protected void initRun() {
        super.initRun();
       if(this.id == 1){
           valueCount = 0;
           valueIndex = domain[valueCount];
           upperBound = Integer.MAX_VALUE;
           accCost = Integer.MAX_VALUE;
           nextAgent = 2;
           sendNextMessage(nextAgent,valueIndex,accCost);
           nextAgent++;
       }
    }

    private void sendNextMessage(int nextAgent, int valueIndex, int accCost) {
        Message msg = new Message(this.id,nextAgent,valueIndex,accCost);
        sendMessage(msg);
    }


    @Override
    public Object printResults(List<Map<String, Object>> results) {
        return null;
    }

    @Override
    public String easyMessageContent(Message msg, AgentCycle sender, AgentCycle receiver) {
        return null;
    }

    @Override
    protected void disposeMessage(Message msg) {
        switch (msg.getType()){
            case TYPE_PREV_MSG:
                disposePreviousMessage(msg);
                break;
            case TYPE_NEXT_MSG:
                disposeNextMessage(msg);
                break;
        }
    }

    private void disposePreviousMessage(Message msg) {

    }

    private void disposeNextMessage(Message msg) {
    }


    @Override
    protected void messageLost(Message msg) {

    }
}
